NAME
    FML::Command::Admin::newcopml - set up a new create-on-post mailing
    list.

SYNOPSIS
        use FML::Command::Admin::newcopml;
        $obj = new FML::Command::Admin::newcopml;
        $obj->newcopml($curproc, $command_context);

    See "FML::Command" for more details.

DESCRIPTION
    set up a new virtual mailing list for create-on-post operation.
    Actually, run "make newml" operation to create a new ML.

    After that, modify it for create-on-post operation. We use this virtual
    ML for spooling and logging only. The actual processing is done by
    FML::Process::CreateOnPost process.

METHODS
  new()
    constructor.

  need_lock()
    not need lock in the first time.

  process($curproc, $command_context)
    main dispatcher.

  cgi_menu($curproc, $command_context)
    show cgi menu for newcopml command.

UTILITIES
  set_force_mode($curproc, $command_context)
    set force mode.

  get_force_mode($curproc, $command_context)
    return if force mode is enabled or not.

CODING STYLE
    See "http://www.fml.org/software/FNF/" on fml coding style guide.

AUTHOR
    Ken'ichi Fukamachi

COPYRIGHT
    Copyright (C) 2006 Ken'ichi Fukamachi

    All rights reserved. This program is free software; you can redistribute
    it and/or modify it under the same terms as Perl itself.

HISTORY
    FML::Command::Admin::newcopml first appeared in fml8 mailing list driver
    package. See "http://www.fml.org/" for more details.

