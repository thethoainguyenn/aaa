NAME
    FML::Command::Admin::rmcopml - disable a new create-on-post mailing
    list.

SYNOPSIS
        use FML::Command::Admin::rmcopml;
        $obj = new FML::Command::Admin::rmcopml;
        $obj->rmcopml($curproc, $command_context);

    See "FML::Command" for more details.

DESCRIPTION
    remove the specified ML (virtual create-on-post top level entrance).
    After that, purge the relation between virtual domain configurations and
    ML's.

METHODS
  new()
    constructor.

  need_lock()
    not need lock in the first time.

  process($curproc, $command_context)
    main dispatcher.

  cgi_menu($curproc, $command_context)
    show cgi menu for rmcopml command.

UTILITIES
  set_force_mode($curproc, $command_context)
    set force mode.

  get_force_mode($curproc, $command_context)
    return if force mode is enabled or not.

CODING STYLE
    See "http://www.fml.org/software/FNF/" on fml coding style guide.

AUTHOR
    Ken'ichi Fukamachi

COPYRIGHT
    Copyright (C) 2006 Ken'ichi Fukamachi

    All rights reserved. This program is free software; you can redistribute
    it and/or modify it under the same terms as Perl itself.

HISTORY
    FML::Command::Admin::rmcopml first appeared in fml8 mailing list driver
    package. See "http://www.fml.org/" for more details.

